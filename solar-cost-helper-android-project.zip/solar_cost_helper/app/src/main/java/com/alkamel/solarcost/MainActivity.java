package com.alkamel.solarcost;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private EditText billInput, commercialRateInput, normalRateInput, totalKwhInput;
    private TextView resultView, detailView;
    private SharedPreferences prefs;
    private final DecimalFormat fmt = new DecimalFormat("#,##0.##");
    private int navy = Color.rgb(7,59,76), teal = Color.rgb(22,138,173), pale = Color.rgb(235,248,251);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("solar_cost_data", MODE_PRIVATE);
        buildUi();
        loadSaved();
        calculate();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(18),dp(18),dp(24)); root.setBackgroundColor(Color.rgb(246,249,250));
        scroll.addView(root);
        TextView title = text("حاسبة فرق تكلفة الكهرباء", 24, Color.WHITE, true);
        title.setGravity(Gravity.CENTER); title.setPadding(dp(12),dp(22),dp(12),dp(22)); title.setBackgroundColor(navy);
        root.addView(title, matchWrap());
        TextView intro = text("احسب الزيادة العادلة على سعر الكيلو عند الاضطرار لاستخدام الكهرباء التجاري.", 15, navy, false);
        intro.setPadding(dp(4),dp(14),dp(4),dp(12)); root.addView(intro);

        billInput = field(root, "إجمالي فاتورة الكهرباء التجاري (ريال)", "10000");
        commercialRateInput = field(root, "سعر الكيلو التجاري (ريال)", "290");
        normalRateInput = field(root, "سعر الكيلو المعتاد للمشترك (ريال)", "180");
        totalKwhInput = field(root, "إجمالي استهلاك جميع المشتركين للفترة (كيلوواط ساعة)", "500");

        Button calc = button("احسب الزيادة", teal); root.addView(calc, matchWrap());
        calc.setOnClickListener(v -> { saveInputs(); calculate(); });
        resultView = text("", 19, navy, true); resultView.setGravity(Gravity.CENTER);
        resultView.setPadding(dp(14),dp(18),dp(14),dp(18)); resultView.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams rp = matchWrap(); rp.topMargin = dp(14); root.addView(resultView,rp);
        detailView = text("", 15, Color.DKGRAY, false); detailView.setPadding(dp(12),dp(12),dp(12),dp(12));
        root.addView(detailView, matchWrap());

        Button history = button("عرض آخر عملية محفوظة", navy); root.addView(history, matchWrap());
        history.setOnClickListener(v -> showHistory());
        Button reset = button("إعادة القيم الافتراضية", Color.GRAY); root.addView(reset, matchWrap());
        reset.setOnClickListener(v -> { billInput.setText("10000"); commercialRateInput.setText("290"); normalRateInput.setText("180"); totalKwhInput.setText("500"); saveInputs(); calculate(); });
        TextView footer = text("يعمل دون إنترنت • تُحفظ القيم على الهاتف • إصدار أولي قابل للتطوير", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(18),0,0); root.addView(footer);
        setContentView(scroll);
    }

    private EditText field(LinearLayout parent, String label, String defaultValue) {
        TextView l = text(label, 14, navy, true); l.setPadding(dp(2),dp(10),dp(2),dp(5)); parent.addView(l);
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(17); e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(defaultValue); e.setSelectAllOnFocus(false); e.setPadding(dp(12),dp(10),dp(12),dp(10)); e.setBackgroundColor(Color.WHITE);
        parent.addView(e, matchWrap()); return e;
    }

    private void calculate() {
        try {
            double bill = number(billInput), commercial = number(commercialRateInput), normal = number(normalRateInput), total = number(totalKwhInput);
            if (bill < 0 || commercial <= 0 || normal < 0 || total <= 0) throw new IllegalArgumentException("تأكد أن الفاتورة والاستهلاك غير سالبين، وأن الأسعار والاستهلاك الإجمالي أكبر من صفر.");
            if (commercial < normal) throw new IllegalArgumentException("سعر التجاري أقل من السعر المعتاد؛ راجع الأسعار المدخلة.");
            double commercialKwh = bill / commercial;
            double differencePerCommercialKwh = commercial - normal;
            double extraCost = commercialKwh * differencePerCommercialKwh;
            double addedPerSoldKwh = extraCost / total;
            double newRate = normal + addedPerSoldKwh;
            resultView.setText("الزيادة لكل كيلو: " + fmt.format(addedPerSoldKwh) + " ريال\nالسعر الجديد المقترح: " + fmt.format(newRate) + " ريال/كيلو");
            detailView.setText("تفاصيل الحساب\n\n1) استهلاك التجاري التقديري = الفاتورة ÷ سعر التجاري = " + fmt.format(commercialKwh) + " كيلو\n\n2) فرق السعر لكل كيلو تجاري = " + fmt.format(differencePerCommercialKwh) + " ريال\n\n3) إجمالي فرق التكلفة = " + fmt.format(extraCost) + " ريال\n\n4) الزيادة لكل كيلو من إجمالي استهلاك المشتركين = " + fmt.format(extraCost) + " ÷ " + fmt.format(total) + " = " + fmt.format(addedPerSoldKwh) + " ريال\n\nملاحظة: هذا الحساب يوزّع فرق السعر فقط، ولا يوزّع كامل فاتورة التجاري.");
            prefs.edit().putString("last_bill", billInput.getText().toString()).putString("last_commercial", commercialRateInput.getText().toString()).putString("last_normal", normalRateInput.getText().toString()).putString("last_total", totalKwhInput.getText().toString()).putString("last_result", resultView.getText().toString()).putString("last_details", detailView.getText().toString()).apply();
        } catch (Exception ex) {
            resultView.setText("تعذّر الحساب"); detailView.setText(ex.getMessage() == null ? "تأكد من إدخال أرقام صحيحة." : ex.getMessage());
        }
    }

    private void saveInputs() { prefs.edit().putString("last_bill", billInput.getText().toString()).putString("last_commercial", commercialRateInput.getText().toString()).putString("last_normal", normalRateInput.getText().toString()).putString("last_total", totalKwhInput.getText().toString()).apply(); }
    private void loadSaved() {
        billInput.setText(prefs.getString("last_bill", "10000")); commercialRateInput.setText(prefs.getString("last_commercial", "290"));
        normalRateInput.setText(prefs.getString("last_normal", "180")); totalKwhInput.setText(prefs.getString("last_total", "500"));
    }
    private void showHistory() {
        String history = prefs.getString("last_result", "لا توجد عملية محفوظة بعد.") + "\n\n" + prefs.getString("last_details", "");
        new AlertDialog.Builder(this).setTitle("آخر عملية محفوظة").setMessage(history).setPositiveButton("إغلاق", null).show();
    }
    private double number(EditText e) { String s = e.getText().toString().trim().replace(',', '.'); if (s.length()==0) throw new IllegalArgumentException("أكمل جميع الحقول بالأرقام أولًا."); return Double.parseDouble(s); }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.RIGHT); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t; }
    private Button button(String label, int color) { Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false); b.setBackgroundColor(color); LinearLayout.LayoutParams p = matchWrap(); p.topMargin = dp(10); b.setLayoutParams(p); return b; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
